<template>
  <div id="Home">{{Home}}</div>
</template>

<script>
export default {
  name: "Home",
  data() {
    return {
      Home: "Home"
    };
  },
  components: {}
};
</script>
