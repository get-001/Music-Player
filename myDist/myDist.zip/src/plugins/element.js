import Vue from "vue";
import {
  Message
  // Loading, MessageBox, Input, Button
} from "element-ui";

// Vue.use(Button);
// Vue.use(Input);
// Vue.use(Loading.directive);

// Vue.prototype.$loading = Loading.service;
// Vue.prototype.$msgbox = MessageBox;
// Vue.prototype.$alert = MessageBox.alert;
// Vue.prototype.$confirm = MessageBox.confirm;
// Vue.prototype.$prompt = MessageBox.prompt;
Vue.prototype.$message = Message;
